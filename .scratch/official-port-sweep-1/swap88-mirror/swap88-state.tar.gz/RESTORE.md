# Restoring this snapshot

Contents: `worktree/` (working-tree bytes of every tracked-dirty path), `stages/`
(every unmerged index stage, `%`-escaped path + `.stage1|2|3`), `gitdir/` (the
worktree's own `index`, `HEAD`, `MERGE_MSG`), `meta/` (status, path lists, head).

Preferred restore is always the real branch (`git clone`/`fetch` `swap/qwen-88` once
it has a commit). This snapshot is for the pre-commit window only.

On the host that has the objects (`e16d574bb` + official `e126687a9a`):

    git worktree add ~/dev/vllm-swap88 -b swap/qwen-88 <head.txt sha>   # or reuse it
    tar xzf swap88-state.tar.gz -C /tmp/r
    # 1. recreate the unmerged index exactly (base, ours, theirs).
    #    meta/unmerged_stages.txt lines are: '    <mode> <sha> <stage>\t<path>'
    sed 's/^ *//' /tmp/r/meta/unmerged_stages.txt | while read -r mode sha stage path; do
      g=$(git hash-object -w "/tmp/r/stages/$(printf '%s' "$path" | tr '/' '%').stage$stage")
      git update-index --cacheinfo "$mode,$g,$path"
    done
    # 2. working-tree bytes
    ( cd /tmp/r/worktree && find . -type f -print0 | while IFS= read -r -d '' f; do
        mkdir -p ~/dev/vllm-swap88/$(dirname "$f"); cp "$f" ~/dev/vllm-swap88/"$f"; done )
    # 3. copy the 8 .so from ~/dev/vllm-so-d4d703c.tgz (excluded from this snapshot)
    cp /tmp/r/gitdir/index ~/dev/vllm-swap88/$(cd ~/dev/vllm-swap88 && git rev-parse --git-dir)/index

Verify after restore: `git status --porcelain` must equal `meta/status_porcelain.txt`,
and `md5 -q` of a sample of `worktree/` files must match the restored files.
